#include <fcntl.h>

int main(int argc, char* argv[]) {
	http://pubs.opengroup.org/onlinepubs/7908799/xsh/sysstat.h.html
	creat(argv[1], S_IRWXU);
}