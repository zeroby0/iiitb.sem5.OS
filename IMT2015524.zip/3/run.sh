gcc creat.c -o create
./create newfile.txt