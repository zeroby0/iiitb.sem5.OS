gcc openfile.c -o openfile
./openfile test.txt