gcc copy.c -o copy
./copy test.txt copy.txt