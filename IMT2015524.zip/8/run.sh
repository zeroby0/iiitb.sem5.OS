gcc cat.c -o cat
./cat test.txt